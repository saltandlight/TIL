package com.example.p485;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

import static java.lang.Thread.*;

public class MainActivity extends AppCompatActivity {

    TextView tx_avg;
    TextView tx_speed;
    TextView tx_rpm;
    MyThread myThread;
    MyHandler myHandler;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tx_avg=findViewById(R.id.average);
        tx_speed=findViewById(R.id.speed);
        tx_rpm=findViewById(R.id.rpm);
        button=findViewById(R.id.button);
       // myThread=new MyThread();
        myHandler=new MyHandler();
    }


    public void clickBt(View view){
        myThread=new MyThread();
        myThread.setCnt(20);
        myThread.start();
        button.setEnabled(false);

    }



    class MyHandler extends Handler{
        @Override
        public void handleMessage(@NonNull Message msg) {
            Bundle bundle=msg.getData();
            int rpm=bundle.getInt("rpm");
            int speed=bundle.getInt("speed");
            float avg=bundle.getFloat("avg");
            tx_rpm.setText(rpm+"");
            tx_speed.setText(speed+"");
            tx_avg.setText(avg+"");
        }
    }


    // random 하게 만들어서 보내주기

    class MyThread extends Thread{
        int cnt;
        int speed;
        int rpm;
        float avg;

        public MyThread(){
        }
        public void setCnt(int cnt){
            this.cnt=cnt;
        }

        public void setSpeed(int speed) {
            this.speed=speed;
        }

        public void setRpm(int rpm) {
            this.rpm=rpm;
        }

        public void setAvg(float avg) {
            this.avg =avg;
        }

        //ㅁ만들어진 값을 핸들러로 한 번 찍어보기
        //runonui쓰지 말고 접근해보기
        // handler로 자꾸 쏘는 것(textView에)

        @Override
        public void run(){
            //여기서 계속 생성되도록 해야 할 듯!
            Random r= new Random();
            for(int i=0;i<cnt;i++){
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Log.d("[T2]", "----------"+i);

                rpm=r.nextInt(1000)+6000;
                speed = r.nextInt(260)+1;
                avg = ((float)rpm )/ ((float)speed);

                Message message=myHandler.obtainMessage();
                Bundle bundle = new Bundle();
                bundle.putInt("rpm", rpm);
                bundle.putInt("speed", speed);
                bundle.putFloat("avg", avg);
                message.setData(bundle);
                myHandler.sendMessage(message);
            }runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    button.setEnabled(true);
                }
            });
        }
    }



}
