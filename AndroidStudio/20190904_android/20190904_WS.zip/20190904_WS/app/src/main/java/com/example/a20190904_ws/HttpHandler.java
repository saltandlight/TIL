package com.example.a20190904_ws;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpHandler {
    public static String getString(String urlstr){
        //url에 접속함.
        String result=null;
        URL url=null;
        HttpURLConnection hcon=null;
        BufferedInputStream is=null;


        try {
            url = new URL(urlstr);
            hcon=(HttpURLConnection) url.openConnection();
            hcon.setConnectTimeout(10000);
            hcon.setRequestMethod("GET");
            is=new BufferedInputStream(hcon.getInputStream());
            result=convertStr(is);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            hcon.disconnect();
        }
        return result;
    }

    private static String convertStr(BufferedInputStream is) {
        BufferedReader br = null;
        br=new BufferedReader(new InputStreamReader(is));
        StringBuilder sb= new StringBuilder();
        String temp;
        try{
            //한 라인씩 읽고 temp에 집어넣음.
            while((temp = br.readLine()) != null){
                sb.append(temp);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        return sb.toString();
    }
}
