package com.example.a20190904_ws;

public class Item {
    String name;
    String date;
    String rate;
    String img;

    public Item() {
    }

    public Item(String name, String date, String rate, String img) {
        this.name = name;
        this.date = date;
        this.rate = rate;
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
